package student;

 enum  Gender{
	   MALE, 
       FEMALE;
}