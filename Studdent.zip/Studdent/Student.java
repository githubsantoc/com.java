package student;

public class Student{
	public static void main(String[] args){
		int count = 0;
		Stu s[] = new Stu[]{
			new Stu("Santoshi",Gender.FEMALE, 10, 'A', 1, "9860810636", "sant@gmail.com"),
			new Stu("Samita", Gender.FEMALE, 10, 'A', 2, "9863256617", "sami@gmail.com"),
			new Stu("Saraswoti", Gender.FEMALE, 10, 'A', 3, "9849319128", "sars@gmail.com"),
			new Stu("Deepak", Gender.MALE, 10, 'A', 4, "9841482118", "deep@gmail.com"),
			new Stu("Dipesh", Gender.MALE, 10, 'A', 5, "9849978086", "dip@gmail.com"),
		};
		
	
		
		for(Stu s1:s){
			System.out.println(s1);
			System.out.println();
			count++;
		}
		
		
		s[0].pass(11, 'B', 22);
		System.out.println("The updated value is \n ");
		System.out.println(s[0]);
		
	
		
		System.out.println("\n The total number of student is "+ count);
		
		
			
	}
}
		 