package student;

public class Stu{
	final private String name;
	int grade;
	char section;
	int rollNumber;
	String phoneNumber;
	String email;
	Gender gen;
   
	
	public Stu(String name, Gender gen, int grade, char section, int rollNumber, String phoneNumber, String email){
		
		this.name = name;
		this.gen = gen;
		this.grade= grade;
		this.section = section;
		this.rollNumber = rollNumber;
		this.phoneNumber = phoneNumber;
		this.email= email;
	}
	
	@Override
	public String toString(){
		return "name= "+ name
		+"\nGender = " + gen		
		+"\nClass = " + grade 
		+"\nSection = " + section 
		+"\nRoll Number = " + rollNumber 
		+"\nPhone Number = " + phoneNumber
		+"\nEmail = " + email;
	}
	
	
	public void pass(int grade, char sec, int roll){
		this.grade = grade;
		this.section = section;
		this.rollNumber= roll;
	}
	
	public void setPhone(String phone) {
		this.phoneNumber = phone;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
}
	
	
	
	
	